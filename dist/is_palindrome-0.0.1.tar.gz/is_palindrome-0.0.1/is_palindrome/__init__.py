"""python package for checking palindrome property in a string"""
__version__ = "0.0.1"